<!doctype html>
<?php include('./phpfunctions/header.php') ?> 
<br>
<br>
<?php

if (isset($_POST['submit']) && isset($_FILES['CVtoUpload']))
{
    include('./phpfunctions/newApply.php'); 
    
}
else
    {
    include('./phpfunctions/jobApplication.php');
    
    }
?>

        

<?php include('./phpfunctions/footer.php') ?> 