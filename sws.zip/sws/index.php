<?php include('./phpfunctions/header.php') ?> 
    
    
  
    
    <!-- ====== Hero Area ====== -->

    
    
    <div class="hero-aria" id="home">
        
        <!-- Hero Area Content -->
        <div class="container">
            <div class="hero-content h-100">
                <div class="d-table">
                    <div class="d-table-cell">
                        <a class="logoslider">
                    <img style='max-width: 50%;' src="assets/images/logosws.png" alt="logo">
                </a>
                        <h3 class="text-uppercase"><span class="typed"></span></h3>
                        <p>Your Safety Is Our Safety.</p>
        <a style='color: black' href="contact.php" class="button smooth-scroll">Contact Us</a>
                    </div>
                </div>
            </div>
            
        </div>
        <!-- // Hero Area Content -->
        <!-- Hero Area Slider -->
        
        <div style='background-image: url("assets/images/1234.jpg"); background-repeat: no-repeat; background-size: cover;' id="particles-js"></div>
        
        <!-- // Hero Area Slider -->
    </div>
    
    
    <!-- ====== //Hero Area ====== -->
    
    
    
    
    
    
    
    
    
    
    

    <!-- ====== Service Section ====== -->
    <section id="service" class="section-padding pb-70 service-area bg-secondary">
        <div class="container">
            <!-- Section Title -->
            <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="section-title text-center">
                        <h2>What We Offer</h2>
                        <p></p>
                    </div>
                </div>
            </div>
            <!-- //Section Title -->

            <div class="row">
                <!-- Single Service -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-service">
                        <div class="service-icon">
                            <i class="fa fa-clipboard"></i>
                        </div>
                        <h2><a href="forklifttraining.php" style='color:black' onmouseover="this.style.color='#FFFFFF'"  onmouseout="this.style.color='#000'" >Forklift Training</a></h2>
                        <p>Make the right choice for your company. SWS Training (A Division Of Safe Work Solutions Inc.) delivers high-quality, industry recognized forklift training programs.</p>
                    </div>
                </div>
                <!-- //Single Service -->
                <!-- Single Service -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-service">
                        <div class="service-icon">
                            <i class="fa fa-desktop"></i>
                        </div>
                        <h2><a href="ost.php" style='color:black' onmouseover="this.style.color='#FFFFFF'"  onmouseout="this.style.color='#000'" >Online Safety Training</a></h2>
                        <p>Modern, Flexible and Efficient. Providing top-quality online safety training.<br>
                            <br>
                            <br></p>
                    </div>
                </div>
                <!-- //Single Service -->
                <!-- Single Service -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-service">
                        <div class="service-icon">
                            <i class="fa fa-handshake"></i>
                        </div>
                        <h2><a href="looking.php" style='color:black' onmouseover="this.style.color='#FFFFFF'"  onmouseout="this.style.color='#000'" >Staffing</a></h2>
                        <p>We pride ourselves on building strong and long-lasting relationships with our clients, our priority is to understand your business and talent needs.<br>
                            
                            </p>
                    </div>
                </div>
                
                
                <!-- //Single Service -->
                
            </div>
            
            <div class="row">
                
                <!-- Single Service -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-service">
                        <div class="service-icon">
                            <i class="fa fa-dolly"></i>
                        </div>
                        <h2><a href="service.php" style='color:black' onmouseover="this.style.color='#FFFFFF'"  onmouseout="this.style.color='#000'" >Equipment</a></h2>
                        <p>Our vast inventory of forklifts and parts will meet the needs of any company, no matter how specific, and our short term and long term rental and financing options will accommodate any budget.</p>
                    </div>
                </div>
                <!-- //Single Service -->
                
                
            </div>
        </div>
    </section>
    <!-- ====== //Service Section ====== -->

    
    
    
    
    
    
    
    <!-- ====== Why choose Me Section ====== -->
    <section class="section-padding why-choose-us pb-70">
        <div class="container">
            <!-- Section Title -->
            <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="section-title2 text-center">
                        <h2>Why Choose Us?</h2>
                        <p></p>
                    </div>
                </div>
            </div>
            <!-- //Section Title -->
            <div class="row">
                <!-- Single Why choose me -->
                <div class="col-md-6">
                    <div class="single-why-me why-me-left">
                        <div class="why-me-icon">
                            <div class="d-table">
                                <div class="d-table-cell">
                                    <i class="fa fa-clock"></i>
                                </div>
                            </div>
                        </div>
                        <h4>24/7/365</h4>
                        <p>We provide an unmatched level of support
We work around the clock. We are available to our clients 24/7/365.</p>
                    </div>
                </div>
                <!-- // Single Why choose me -->

                <!-- Single Why choose me -->
                <div class="col-md-6">
                    <div class="single-why-me why-me-right">
                        <div class="why-me-icon">
                            <div class="d-table">
                                <div class="d-table-cell">
                                    <i class="fa fa-heart"></i>
                                </div>
                            </div>
                        </div>
                        <h4>We&#39;re Passionate About What We Do</h4>
                        <p>We&#39;re passionate about the
services we provide and quality of support.</p>
                    </div>
                </div>
                <!-- // Single Why choose me -->

                <!-- Single Why choose me -->
                <div class="col-md-6">
                    <div class="single-why-me why-me-left">
                        <div class="why-me-icon">
                            <div class="d-table">
                                <div class="d-table-cell">
                                    <i class="fa fa-user"></i>
                                </div>
                            </div>
                        </div>
                        <h4>Our Customers Are Our Biggest Asset</h4>
                        <p>We value our customers and do everything possible to ensure their happiness.
That is our promise.</p>
                    </div>
                </div>
                <!-- // Single Why choose me -->

                <!-- Single Why choose me -->
                <div class="col-md-6">
                    <div class="single-why-me why-me-right">
                        <div class="why-me-icon">
                            <div class="d-table">
                                <div class="d-table-cell">
                                    <i class="fa fa-dollar-sign"></i>
                                </div>
                            </div>
                        </div>
                        <h4>Flexible Pricing Policy</h4>
                        <p>We offer attractive and stable pricing with a perfect balance between quality and price.</p>
                    </div>
                </div>
                <!-- // Single Why choose me -->
            </div>
        </div>
    </section>
    <!-- ====== //Why choose Me Section ====== -->
    
    
    
    
    
    
    
    
    
    
    <!-- ====== Fact Counter Section ====== -->
    <!-- ====================================================================
            NOTE: You need to change  'data-count="10"' and 'p' Elements 
        ===================================================================== -->
    <section class="section-padding pb-70 bg-img fact-counter" id="counter" style="background-image: url(assets/images/w3.jpg)">
        <div class="container">
            <div class="row">
                <!-- Single Fact Counter -->
                <div class="col-lg-3 co col-md-6 l-md-6 text-center">
                    <div class="single-fun-fact">
                        <h2><span class="counter-value" data-count="05">5</span>+</h2>
                        <p>Years Experience</p>
                    </div>
                </div>
                <!-- // Single Fact Counter -->
                <!-- Single Fact Counter -->
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="single-fun-fact">
                        <h2><span class="counter-value" data-count="3000">3000</span>+</h2>
                        <p>Students Trained</p>
                    </div>
                </div>
                <!-- // Single Fact Counter -->
                <!-- Single Fact Counter -->
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="single-fun-fact">
                        <h2><span class="counter-value" data-count="250">250</span>+</h2>
                        <p>Candidates Placed</p>
                    </div>
                </div>
                <!-- // Single Fact Counter -->
                <!-- Single Fact Counter -->
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="single-fun-fact">
                        <h2><span class="counter-value" data-count="999">999</span>+</h2>
                        <p>Cups of Coffee</p>
                    </div>
                </div>
                <!-- // Single Fact Counter -->
            </div>
        </div>
    </section>
    <!-- ====== //Fact Counter Section ====== -->
    
<?php include('./phpfunctions/footer.php') ?>    
    
    
    
    
    
    
    
    
    
    
    
    

