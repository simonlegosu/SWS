<?php include('./phpfunctions/header.php') ?> 
    
    
<center><div style='background-color: #ffc900'>
        
        
    <!-- ====== Page Content ====== -->
    
<div style='text-align: center; background-color: #ffc900'>
    
 
	  
    <!-- Page Heading/Breadcrumbs -->
    
    

  
     

      <!-- Blog Entries Column -->
      

        <!-- Blog Post -->
        <div class="card-noborder mb-4">
          <img style='max-width: 120%;' src="assets/images/logo.png" alt="looking for staff">
          <div class="card-body">
            
            <p class="card-text">
               
			For the last 25 years, our partner has been striving to provide high quality and speedy service at a reasonable price. Our goal is to help you keep your company’s down time at a minimum, and to keep all of our customers satisfied.

Our technicians have been trained to maintain, repair or rebuild your material handling equipment quickly and effectively to get your company up and running again as soon as possible. We also sell and rent various types of new and used equipment for your long-term or short-term needs.

Our clients have come to rely on us for swift, skilled and flexible service with a personal touch, because our clients come first. When it comes to your warehousing and material handling needs, you will not find the same caliber of service anywhere else.</p>
            
			  
          
        </div>
          
      </div>

      </div>


          
        </div>
    
    <!-- ====== // Page Content ====== -->
    
    
    </center>

    

 <?php include('./phpfunctions/footer.php') ?> 