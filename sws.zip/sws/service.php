<?php include('./phpfunctions/header.php') ?> 

    <!-- ====== Service Section ====== -->
    <section id="service" class="section-padding pb-70 service-area bg-secondary">
        <div class="container">
            <!-- Section Title -->
            <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="section-title text-center">
                        <h2>Need a fix?</h2>
                        <p>The competence, engagement, and availability of our team enable us to provide you with quality work within a guaranteed time. Our experienced technicians are trained to service all types of material handling equipment.</p>
                    </div>
                </div>
            </div>
            <!-- //Section Title -->

            <div class="row">
                <!-- Single Service -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-service">
                        <div class="service-icon">
                            <i class="fa fa-cogs"></i>
                        </div>
                        <h2><a href="#" style='color:black' onmouseover="this.style.color='#FFFFFF'"  onmouseout="this.style.color='#000'" >Service</a></h2>
                        <p>If you currently own material handling equipment that it is malfunctioning or broken, you can place a service call and have a trained Mobiltech technician come inspect your machine on location as soon as possible to determine the work required to get your machine back on track. For more time-consuming repairs we offer the possibility of renting a replacement forklift while your machine is down.</p><br>
                    </div>
                </div>
                <!-- //Single Service -->
                <!-- Single Service -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-service">
                        <div class="service-icon">
                            <i class="fa fa-clipboard-list"></i>
                        </div>
                        <h2><a href="#" style='color:black' onmouseover="this.style.color='#FFFFFF'"  onmouseout="this.style.color='#000'" >Maintenance Contracts</a></h2>
                        <p>Our preventative maintenance service is available on an as-needed as well as on a contract basis. These scheduled follow-ups allow our customers to be proactive in controlling the condition and ensuring the efficiency of their fleet, while eliminating down time and preventing bigger and costlier problems down the line.
Our expert technicians will periodically evaluate the state of your lifts and issue a detailed inspection report after each visit. 

                            </p>
                    </div>
                </div>
                <!-- //Single Service -->
                <!-- Single Service -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-service">
                        <div class="service-icon">
                            <i class="fa fa-calendar-plus"></i>
                        </div>
                        <h2><a href="#" style='color:black' onmouseover="this.style.color='#FFFFFF'"  onmouseout="this.style.color='#000'" >Additional Services</a></h2>
                        <p>We provide other material handling services such as: sales of replacement parts; emission testing; sales, repair and installation of chargers, batteries, tires and a wide array of industrial parts, including forklift attachments. We also offer a battery cleaning service, using Mobil-Kleen, our very own patented and competitively-priced battery cleaner and acid neutralizer.
                            <br><br><br></p>
                    </div>
                </div>
                
                
                <!-- //Single Service -->
                
            </div>
        </div>
    </section>
    <!-- ====== //Service Section ====== -->

    <?php include('./phpfunctions/footer.php') ?> 
    
    
    
    
