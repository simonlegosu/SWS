<?php include('./phpfunctions/header.php') ?> 
    
    <!-- ====== Service Section ====== -->
    <section id="service" class="section-padding pb-70 service-area bg-secondary">
        
    <!-- Section Title -->
            <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="section-title text-center">
                        <h2>Need Equipments?</h2>
                        <p></p>
                    </div>
                </div>
            </div>
            <!-- //Section Title -->
        
    </section>
    
    
<center><div style='background-color: #ffc900'>
        
        
    <!-- ====== Page Content ====== -->
    
<div style='text-align: center; background-color: #ffc900'>
 
	  
    <!-- Page Heading/Breadcrumbs -->
    
    

  
     <div style='background-color: #ffc900' class="row">

      <!-- Blog Entries Column -->
      

        <!-- Blog Post -->
        <div class="card-noborder mb-4">
          
          <div class="card-body">
            
              <p class="card-text">
                
			Whether you are looking to buy new or used parts or equipment, we will do our best to find exactly what you need at the lowest price possible. We even accept trade-ins on any running forklift, if you wish to upgrade your machine in exchange for a credit. We arrange for competitively priced and rapid delivery services to anywhere in and around the Montreal area. If budget is a concern, we can even assist you in financing your newly purchased equipment though flexible and custom-made terms that will suit your needs.
All items in our inventory are available for purchase, but we are not only limited to that list of items.

Give us a call for more information, or simply fill in the Sales Quote Request Form on this page to get a quote by e-mail.</p>
            
			  
         
        </div>
          
      </div>

      </div>


          
        


       
      </div>
    </div></center>

    
    
    <!-- ====== // Page Content ====== -->
    
    
    <!-- Contact Form -->
            
            <div class="row justify-content-center">
                <br><br>
                <div class="col-lg-10">
                    <!-- Form -->
                    <form action="https://formsubmit.co/helpdesk@swscanada.xyz" method="POST" class="contact-form bg-white" >
                <div class="form-group">
                    <div class="form-row">
                        <div class="col">
                            <input type="text" name="name" class="form-control" placeholder="Full Name*" required>
                        </div>
                        <div class="col">
                            <input type="email" name="email" class="form-control" placeholder="Email Address*" required>
                        </div>
                    </div><br>
                    <div class="form-row">
                        <div class="col">
                            <input type="text" name="tel" class="form-control" placeholder="Phone Number*" required>
                        </div>
                        <div class="col">
                            <input type="text" name="company" class="form-control" placeholder="Company Name">
                        </div>
                    </div>
                </div><br>
                <div class="form-group">
                    <textarea placeholder="Your Message*" class="form-control" name="message" rows="14" required></textarea>
                </div>
                        <div class="form-btn text-center">
                            <button type="submit" class="button">Send Message</button></div>
            </form>
                    <!-- // Form -->
                </div>
            </div>
            <!-- // Contact Form -->

    
<?php include('./phpfunctions/footer.php') ?> 
