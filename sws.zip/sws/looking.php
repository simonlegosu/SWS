<?php include('./phpfunctions/header.php') ?> 

    <!-- ====== Page Content ====== -->
<center>
    <div style="background-color: #ffc900">
    <br>
    <br>
    <br>
    </div>
    
    
    
    
    
    
    
    
    
            
            
            
            
            
            <!-- ====== Featured Area ====== -->
    <section id="featured" class="section-padding pb-70 bg-secondary">
        <div class="container">
            <div class="row">
                <!-- single featured item -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-featured-item-wrap">
                        
                        <div class="single-featured-item">
                            
                            <p>We help businesses to find the talent that they need in order to drive their growth.</p>
                        </div>
                    </div>
                </div>
                <!-- single featured item -->
                <!-- single featured item -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-featured-item-wrap">
                        
                        <div class="single-featured-item">
                            
                            <p>We match talent with talent.

Client or candidate, we’ll make great things

happen.</p>
                        </div>
                    </div>
                </div>
                <!-- single featured item -->
                <!-- single featured item -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-featured-item-wrap">
                        
                        <div class="single-featured-item">
                            
                            <p>We are passionate about people in the workplace.</p>
                        </div>
                    </div>
                </div>
                <!-- single featured item -->
            </div>
        </div>
    </section>
    <!-- ====== //Featured Area ====== -->
    
    
    
    
    
    
    <!-- ====== Why choose Me Section ====== -->
    <section class="section-padding why-choose-us pb-70 bg-secondary">
        <div class="container">
            <!-- Section Title -->
            <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="section-title text-center">
                        <h2>Our Pre-Screening Process</h2>
                        <p>Safe Work Solutions Inc. will ensure all
candidates presented to the Client will be pre-screened, which includes, but is not limited
to, the following</p>
                    </div>
                </div>
            </div>
            <!-- //Section Title -->
            <div class="row">
                <!-- Single Why choose me -->
                <div class="col-md-6">
                    <div class="single-why-me why-me-left">
                        <div class="why-me-icon">
                            <div class="d-table">
                                <div class="d-table-cell">
                                    <i class="fa fa-credit-card"></i>
                                </div>
                            </div>
                        </div>
                        <h4>Credit Check Verification<br><br></h4>
                        <p></p>
                    </div>
                </div>
                <!-- // Single Why choose me -->

                <!-- Single Why choose me -->
                <div class="col-md-6">
                    <div class="single-why-me why-me-right">
                        <div class="why-me-icon">
                            <div class="d-table">
                                <div class="d-table-cell">
                                    <i class="fa fa-gavel"></i>
                                </div>
                            </div>
                        </div>
                        <h4 >Criminal Record Verification<br><br></h4>
                        <p></p>
                    </div>
                </div>
                <!-- // Single Why choose me -->

                <!-- Single Why choose me -->
                <div class="col-md-6">
                    <div class="single-why-me why-me-left">
                        <div class="why-me-icon">
                            <div class="d-table">
                                <div class="d-table-cell">
                                    <i class="fa fa-user-secret"></i>
                                </div>
                            </div>
                        </div>
                        <h4 >Employment Reference Verification<br><br></h4>
                        <p></p>
                    </div>
                </div>
                <!-- // Single Why choose me -->

                <!-- Single Why choose me -->
                <div class="col-md-6">
                    <div class="single-why-me why-me-right">
                        <div class="why-me-icon">
                            <div class="d-table">
                                <div class="d-table-cell">
                                    <i class="fa fa-graduation-cap"></i>
                                </div>
                            </div>
                        </div>
                        <h4>Education Verification<br><br></h4>
                        <p></p>
                    </div>
                </div>
                <!-- // Single Why choose me -->
                
            </div>
            
        </div>
        
    </section>
    <!-- ====== //Why choose Me Section ====== -->
    
    
            
            
            
            
            
            <!-- ====== Frequently asked questions ====== -->
<section class="section-padding faq-area bg-secondary">
        <div class="container">
            <!-- Section Title -->
            <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="section-title text-center faq-title">
                        <h2>Looking For Staff</h2>
                        <p>We pride ourselves on building strong and long-lasting relationships with our clients, our priority is to understand your business and talent needs.<br><br>Safe Work Solutions Inc. is a talent acquisition firm located in Montreal. 
We take a professional approach to finding the right candidate for our clients
and we build relationships based on trust and responsiveness.</p>
                    </div>
                </div>
            </div>
            <!-- //Section Title -->
            
            
                    <!-- FAQ Content -->
                    <div class="faq-content" id="accordion">

                        <!-- Single FAQ -->
                        <div class="single-faq">

                            <!-- FAQ Header -->
                            <h4 class="collapsed" data-toggle="collapse" data-target="#faq-1">W.E. C.A.R.E.</h4>
                            <!-- // FAQ Header -->

                            <!-- FAQ Content -->
                            <div id="faq-1" class="collapse show" data-parent="#accordion">
                                <div class="faq-body">
                                    <font color="#ffc900"><b>Wisdom:</b></font> We share our knowledge, our expertise and our resources.<br>
                                    <font color="#ffc900"><b>Excellence:</b></font> Highest standards in all that we do. <br>
                                    <font color="#ffc900"><b>Customer Focus:</b></font> Our customers are at the heart of everything we do. <br>
                                    <font color="#ffc900"><b>Accountability:</b></font> We accept responsibility for our actions. <br>
                                    <font color="#ffc900"><b>Results: </b></font> Delivering superior results for our customers.<br>
                                    <font color="#ffc900"><b>Equal Employment Opportunity:</b></font> We ensure all positions are occupied by people who deserve. <br>
                                </div>
                            </div>
                            <!-- FAQ Content -->
                        </div>
                        <!-- // Single FAQ -->

                        <!-- Single FAQ -->
                        <div class="single-faq">

                            <!-- FAQ Header -->
                            <h4 class="collapsed" data-toggle="collapse" data-target="#faq-2">Permanent Staffing</h4>
                            <!-- // FAQ Header -->

                            <!-- FAQ Content -->
                            <div id="faq-2" class="collapse" data-parent="#accordion">
                                <div class="faq-body">
                                    We deliver top-notch, fully-screened and qualified candidates to make it easier for you to find the right people who will contribute to your productivity, innovation and growth.
                                </div>
                            </div>
                            <!-- FAQ Content -->
                        </div>
                        <!-- // Single FAQ -->

                        <!-- Single FAQ -->
                        <div class="single-faq">

                            <!-- FAQ Header -->
                            <h4 class="collapsed" data-toggle="collapse" data-target="#faq-3">Our Expertise</h4>
                            <!-- // FAQ Header -->

                            <!-- FAQ Content -->
                            <div id="faq-3" class="collapse" data-parent="#accordion">
                                <div class="faq-body">
                                    <ul class=" mb-0">
                 	<li>Forklift Operator</li>
					<li>Shipper / Receiver</li>
					<li>Production / Assembly </li>
					<li>Packaging &amp; Containers</li>
					<li>Distribution / Logistics &amp; Supply Chain</li>
					<li>Manufacturing</li>
					<li>Warehouse Associates</li>
					<li>Warehouse Management</li>
					<li>Picker &amp; Packer</li>

                </ul>
                                </div>
                            </div>
                            <!-- FAQ Content -->
                        </div>
                        <!-- // Single FAQ -->

                    </div>
                    <!-- FAQ Content -->
                </div>
            
        
    </section>
    <!-- ====== // Frequently asked questions ====== -->
    
    
    <!-- ====== Call to Action Area ====== -->
    <center>
    <section  class="section-padding call-to-action-aria bg-secondary">
        
            
                
                
                    <div style='text-align: center' class="cta-button">
                        
                            
                                <a href="contact.html" class="button">Contact Us</a>
                            
                        
                        
                    </div>
                
            
        
    </section>
    </center>
        
    <!-- ====== // Call to Action Area ====== -->
    
    
</center>
    <!-- ====== // Page Content ====== -->
    
    
<?php include('./phpfunctions/footer.php') ?> 