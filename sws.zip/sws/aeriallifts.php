<?php include('./phpfunctions/header.php') ?> 
    <!-- ====== Page Content ====== -->
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    
<div class="container">
 <div class="space-top"></div>
	  <div class="space-m"></div>
    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3"></h1>
    

  
    <div class="row">

      <!-- Blog Entries Column -->
      <div class="col-md-8">

        <!-- Blog Post -->
        <div class="card-noborder mb-4">
          <img class="card-img-top imgborder" src="assets/images/aeriallifts/aerialpage.png" alt="looking for staff">
          <div class="card-body">
            
            <p class="card-text">
			<strong>Safe Work Practice For Aerial Lifts & Platforms </strong><br>
                        Any person operating an aerial lift or aerial work platform is required to be trained on the safe use of the equipment as well as any associated hazards.<br><br>

                        Worksite Safety’s Aerial Lifts & Aerial Work Platforms Certification program has been developed in accordance with federal and provincial legislation as safety training for workplaces across Canada. This course consists of 4 chapters and a final exam. Once you pass your exam, you may print your certificates of completion (wallet & wall sized). Training may be paused or resumed at any time.<br><br>

                        This course covers topics such as: The division of responsibilities, personal protective equipment, fall protection considerations, the different types of aerial lifts, operating procedures, associated hazards, and safe work practices.<br><br>

Additional training may be required for the specific equipment you will be operating.  This training is typically provided by the employer and must be delivered by a competent and qualified person.
			</p>
			  
			  <div class="row">
				   <div class="col-md-6">
						<ul class="fa-ul bigli">
                                                    <br>
						  <li><i class="fa-li fa far fa-clock fa-2x text-icon"></i>Average Duration: 1.5 Hours</li>
                                                  <br>
						  <li><i class="fa-li fa fa-print fa-2x text-icon"></i>Printable Certificate Upon Completion</li>
                                                  <br>
						  <li><i class="fa-li fa fas fa-graduation-cap fa-2x text-icon"></i>Unlimited Exam Attempts</li>
                                                  <br>
						  <li><i class="fa-li fas fa-university fa-2x text-icon"></i>Standards Compliant </li>
                                                  <br>
						 </ul>
				   </div>
				   <div class="col-md-6">
						<ul class="fa-ul bigli">
                                                    <br>
						  <li><em class="fa-li fas fa-calendar-alt fa-2x text-icon"></em>Self-Paced. Available 24/7</li>
                                                  <br>
						  <li><i class="fa-li fas fa-users fa-2x text-icon"></i>User Management Tools Available</li>
                                                  <br>
						  <li><i class="fa-li 	far fa-file-alt fa-2x text-icon"></i>Permanent Record Of Training</li>
                                                  <br>
						  <li><i class="fa-li 	fas fa-comment-alt fa-2x text-icon"></i>Live Student Support</li>
                                                  <br>
						</ul>
					</div>
            </div>
         
        </div>
      </div>

      </div>

      <!-- Sidebar Widgets Column -->
      <div class="col-md-4">

        <!-- Search Widget -->
        <div class="card mb-4">
          <h5 class="card-header">Course Outline</h5>
          <div class="card-body">
			
			 <ul>  
				    <li>Mobile Elevating Work Platforms</li>
					<li>Training Requirements</li>
					<li>Elevated Work Platform Basics</li>
					<li>Aerial Lift Hazards</li>
					<li>Stability & Tipping</li>
					<li>Fall Protection</li>
					<li>Inspection Requirements</li>
					<li>Visual Inspection</li>
					<li>Operational Inspection</li>
					<li>Safe Operating Practices</li>
				 					 
				</ul>
			 <div class="text-center">
			  	<a style="border-color: black;color: black; background-color: #ffc900" class="btn btn-primary btn-larg" href="contact.html">GET INFORMATION
          		<span class="glyphicon glyphicon-chevron-right"></span></a> 
			  </div>
			  
          </div>
        </div>


       
      </div>

    </div>
    <!-- /.row -->

  </div>
    
    <!-- ====== // Page Content ====== -->
<?php include('./phpfunctions/footer.php') ?> 