<?php include('./phpfunctions/header.php') ?> 
    
    
    <!-- ====== Service Section ====== -->
    <section id="service" class="section-padding pb-70 service-area bg-secondary">
        
    <!-- Section Title -->
            <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="section-title text-center">
                        <h2>Need Equipments?</h2>
                        <p></p>
                    </div>
                </div>
            </div>
            <!-- //Section Title -->
        
    </section>
    
    
    

<center><div style='background-color: #ffc900'>
        
        
    <!-- ====== Page Content ====== -->
    
<div style='text-align: center; background-color: #ffc900'>
 
	  
    <!-- Page Heading/Breadcrumbs -->
    
    

  
     <div style='background-color: #ffc900' class="row">

      <!-- Blog Entries Column -->
      

        <!-- Blog Post -->
        <div class="card-noborder mb-4">
          
          <div class="card-body">
            
              <p class="card-text">
                
			Whether you have a seasonal need, an important increase in workload, a larger than usual shipment, a breakdown, or you would like to expand your business while keeping expenses low, short or long term rental contracts are the perfect solution for you. Our rental contracts are a flexible and efficient way to get your hands on the necessary equipment immediately without the added burden of managing maintenance costs. All items in our inventory are available to rent, short or long term, or even on a rent-to-buy basis, should you prefer to test the equipment out before committing to such an investment. We arrange for competitively priced delivery services to anywhere in and around the Montreal area. Give us a call for more information, or simply fill in the Rental Quote Request Form on this page to get a quote by e-mail.</p>
            
			  
         
        </div>
          
      </div>

      </div>


          
        


       
      </div>
    </div></center>

    
    
    <!-- ====== // Page Content ====== -->
    
    
    <!-- Contact Form -->
            
            <div class="row justify-content-center">
                <br><br>
                <div class="col-lg-10">
                    <!-- Form -->
                    <form action="https://formsubmit.co/helpdesk@swscanada.xyz" method="POST" class="contact-form bg-white" >
                <div class="form-group">
                    <div class="form-row">
                        <div class="col">
                            <input type="text" name="name" class="form-control" placeholder="Full Name*" required>
                        </div>
                        <div class="col">
                            <input type="email" name="email" class="form-control" placeholder="Email Address*" required>
                        </div>
                    </div><br>
                    <div class="form-row">
                        <div class="col">
                            <input type="text" name="tel" class="form-control" placeholder="Phone Number*" required>
                        </div>
                        <div class="col">
                            <input type="text" name="company" class="form-control" placeholder="Company Name">
                        </div>
                    </div>
                </div><br>
                <div class="form-group">
                    <textarea placeholder="Your Message*" class="form-control" name="message" rows="14" required></textarea>
                </div>
                        <div class="form-btn text-center">
                            <button type="submit" class="button">Send Message</button></div>
            </form>
                    <!-- // Form -->
                </div>
            </div>
            <!-- // Contact Form -->

    
<?php include('./phpfunctions/footer.php') ?> 