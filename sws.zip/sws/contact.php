<?php include('./phpfunctions/header.php') ?> 
    
    <!-- Page Content -->
    <br>
    <br>
    <br>
    <br>
    <br>
  
    
    <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="section-title2 text-center">
                        <h2>Contact Us</h2>
                    </div>
                </div>
            </div>
    
    
    
  <div class="container">

    <!-- Page Heading/Breadcrumbs -->


   
   <center><section class="section-padding faq-area bg-white border">
   <div class="container">
    <!-- Content Row -->
    <div class="center">
    
        <!-- Embedded Google Map -->
      <div>
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11188.956518646644!2d-73.70594785048131!3d45.48512911159297!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cc917ed4855e667%3A0x773e8629b5a98261!2s3700+Griffith+St%2C+Saint-Laurent%2C+QC+H4T+2B3!5e0!3m2!1sen!2sca!4v1554823029814!5m2!1sen!2sca" width="400" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>
      </div>
        <br>
        <div class="col-lg-5">
		        <p> 
          Safe Work Solutions Inc.
          <br>3700 Rue Griffith 
		  <br> Saint-Laurent, QC H4T 2B3
          <br>
        </p>
        <p>
          Phone Number: +1(514)227-3470
        </p>
        <p>
          E-mail:
          <a class="email" href="mailto:helpdesk@swscanada.xyz">helpdesk@swscanada.xyz
          </a>
        </p>
     <!--   <p>
          <abbr title="Hours">H</abbr>: Monday - Friday: 9:00 AM to 5:00 PM
        </p>-->
      </div>
    </div>
   </div>
    <!-- /.row -->
   
       </section></center>
            
            <!-- Contact Form -->
            <br>
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <!-- Form -->
                    <form action="https://formsubmit.co/helpdesk@swscanada.xyz" method="POST" class="contact-form bg-white" >
                <div class="form-group">
                    <div class="form-row">
                        <div class="col">
                            <input type="text" name="name" class="form-control" placeholder="Full Name*" required>
                        </div>
                        <div class="col">
                            <input type="email" name="email" class="form-control" placeholder="Email Address*" required>
                        </div>
                    </div><br>
                    <div class="form-row">
                        <div class="col">
                            <input type="text" name="tel" class="form-control" placeholder="Phone Number*" required>
                        </div>
                        <div class="col">
                            <input type="text" name="company" class="form-control" placeholder="Company Name">
                        </div>
                    </div>
                </div><br>
                <div class="form-group">
                    <textarea placeholder="Your Message*" class="form-control" name="message" rows="14" required></textarea>
                </div>
                        <div class="form-btn text-center">
                            <button type="submit" class="button">Send Message</button></div>
            </form>
                    <!-- // Form -->
                </div>
            </div>
            <br><br>
            <!-- // Contact Form -->
        
    
    <!-- ====== // Contact Area ====== -->


<?php include('./phpfunctions/footer.php') ?> 