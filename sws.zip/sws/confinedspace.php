<?php include('./phpfunctions/header.php') ?> 

    <!-- ====== Page Content ====== -->
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    
<div class="container">
 <div class="space-top"></div>
	  <div class="space-m"></div>
    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3"></h1>
    

  
    <div class="row">

      <!-- Blog Entries Column -->
      <div class="col-md-8">

        <!-- Blog Post -->
        <div class="card-noborder mb-4">
          <img class="card-img-top imgborder" src="assets/images/confinedspace/confinedspacepage.png" alt="looking for staff">
          <div class="card-body">
            
            <p class="card-text">
			<strong>Safe Work Practice For Confined Spaces</strong><br>
			This Confined Spaces Awareness Course will guide you through all aspects of working in a Confined Space, entry and exit, to safe work and rescue procedures. Our comprehensive course will explain in detail what you need to know, emphasize key points and test your knowledge retention after each module. You should check with your employer to see whether or not you need Confined Spaces Training, and to which level of training you will be required to achieve.
			</p>
			  
			  <div class="row">
				   <div class="col-md-6">
						<ul class="fa-ul bigli">
                                                    <br>
						  <li><i class="fa-li fa far fa-clock fa-2x text-icon"></i>Average Duration: 1.5 - 2 Hours</li>
                                                  <br>
						  <li><i class="fa-li fa fa-print fa-2x text-icon"></i>Printable Certificate Upon Completion</li>
                                                  <br>
						  <li><i class="fa-li fa fas fa-graduation-cap fa-2x text-icon"></i>Unlimited Exam Attempts</li>
                                                  <br>
						  <li><i class="fa-li fas fa-university fa-2x text-icon"></i>Standards Compliant </li>
                                                  <br>
						 </ul>
				   </div>
				   <div class="col-md-6">
						<ul class="fa-ul bigli">
                                                    <br>
						  <li><em class="fa-li fas fa-calendar-alt fa-2x text-icon"></em>Self-Paced. Available 24/7</li>
                                                  <br>
						  <li><i class="fa-li fas fa-users fa-2x text-icon"></i>User Management Tools Available</li>
                                                  <br>
						  <li><i class="fa-li 	far fa-file-alt fa-2x text-icon"></i>Permanent Record Of Training</li>
                                                  <br>
						  <li><i class="fa-li 	fas fa-comment-alt fa-2x text-icon"></i>Live Student Support</li>
                                                  <br>
						</ul>
					</div>
            </div>
         
        </div>
      </div>

      </div>

      <!-- Sidebar Widgets Column -->
      <div class="col-md-4">

        <!-- Search Widget -->
        <div class="card mb-4">
          <h5 class="card-header">Course Outline</h5>
          <div class="card-body">
			
			 <ul>  
				    <li>What is a Confined Space?</li>
					<li>How to Safely Enter a Confined Space</li>
					<li>Worker and Employer Responsibilities</li>
					<li>Hazard Recognition and Prevention</li>
				 	<li>Safe Work and Rescue Procedures</li>				 
				</ul>
			 <div class="text-center">
			  	<a style="border-color: black;color: black; background-color: #ffc900" class="btn btn-primary btn-larg" href="contact.html">GET INFORMATION
          		<span class="glyphicon glyphicon-chevron-right"></span></a> 
			  </div>
			  
          </div>
        </div>


       
      </div>

    </div>
    <!-- /.row -->

  </div>
    
    <!-- ====== // Page Content ====== -->
 <?php include('./phpfunctions/footer.php') ?> 