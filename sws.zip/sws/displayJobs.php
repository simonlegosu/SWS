<?php include('./phpfunctions/header.php') ?> 
    
    <!-- Page Content -->
    <br>
    <br>
    <br>
    <br>
    <br>
  
    
    <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="section-title2 text-center">
                        <h2>Jobs Listing</h2>
                    </div>
                </div>
            </div>
    
    
    
  <div class="container space-top">

    <!-- Page Heading/Breadcrumbs -->

            
            <!-- Search Form -->
            <br><br>
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <!-- Form -->
                    <form action="displayJobs.php" method="POST" class="contact-form rounded bg-secondary" style="border:3px solid black" >
                        
                <div class="form-group ">
                    <div class="form-row">
                        <div class="col">
                            <input type="text" class="form-control" placeholder="Keyword" id="keywords" name="search_keywords">
                        </div>
                        <div class="col">
                            <select  name='field' id='category' class='form-control' data-aos="fade-right" data-aos-duration="500">
	<option value='999'>Field</option>
              <?php
                include('./phpfunctions/connectDB.php');
                $query3 = "SELECT * FROM domain_ref";
                $result3 = $conn->query($query3);
                if (!$result3) 
                {
                    die ("Échec d'accès à la base deasdasdasd données : " . $conn->error);
                }

                $row3s = $result3->num_rows;
                for ($j = 0 ; $j < $row3s ; ++$j)
                {
                    $result3->data_seek($j);
                    $row3 = $result3->fetch_array(MYSQLI_NUM);
                    echo "<option class='control' value='$row3[0]'>$row3[1]</option>";
                }
               
                ?>
        </select>
                        </div>
                    </div><br>
                    <div class="form-row">
                        <div class="col">
                            <select  name='jobtype' id='jobtype' class='form-control' data-aos="fade-right" data-aos-duration="500">
                <option value='999'>Job Type</option>                
                    
<?php
                
                $query2 = "SELECT * FROM typeemploi_ref";
                $result2 = $conn->query($query2);
                if (!$result2) 
                {
                    die ("Échec d'accès à la base deasdasdasd données : " . $conn->error);
                }

                $row2s = $result2->num_rows;
                for ($j = 0 ; $j < $row2s ; ++$j)
                {
                    $result2->data_seek($j);
                    $row2 = $result2->fetch_array(MYSQLI_NUM);
                    echo "<option class='control' value='$row2[0]'>$row2[1]</option>";
                }
                
                ?>
                    </select>
                            
                            
                            
                        </div>
                        <div class="col">
                            <select  name='location' id='location' class='form-control' data-aos="fade-left" data-aos-duration="500">
	<option value='999'>Location</option>
        <?php
        
        $query = "SELECT * FROM lieux_ref";
        $result = $conn->query($query);
	if (!$result) 
        {
            die ("Échec d'accès à la base lieux données : " . $conn->error);
        }
        
	$rows = $result->num_rows;
        for ($j = 0 ; $j < $rows ; ++$j)
	{
            $result->data_seek($j);
            $row = $result->fetch_array(MYSQLI_NUM);
            echo "<option class='level-0' value='$row[0]'>$row[1]</option>";
        }
        
        ?>

            </select>
                        </div>
                    </div>
                </div><br>
                        <div class="form-btn text-center">
                            <button type="submit" class="button">Search</button></div>
                            <br><br>
            
<?php 

include('./phpfunctions/accessJobs.php');




?>  
                </form>
                    <!-- // Form -->
                </div>
            </div>
            <!-- // Contact Form -->
        
    
    <!-- ====== // Contact Area ====== -->
  </div>
    <br><br><br>

<?php include('./phpfunctions/footer.php') ?> 