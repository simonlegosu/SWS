<?php include('./phpfunctions/header.php') ?> 

    <!-- ====== Page Content ====== -->
    <div style='background-color: #ffc900'>
    <br>
    <br>
    <br>
    </div>
    
    <!-- ====== Frequently asked questions ====== -->
    <section class="section-padding faq-area bg-secondary">
        <div class="container">
            <!-- Section Title -->
            <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="section-title text-center faq-title">
                        <h2>Job Seekers</h2>
                        <p></p>
                    </div>
                </div>
            </div>
            <!-- //Section Title -->
            
            
            
                    <!-- FAQ Content -->
                    <div class="faq-content" id="accordion">

                        <!-- Single FAQ -->
                        <div class="single-faq">

                            <!-- FAQ Header -->
                            <h4 class="collapsed" data-toggle="collapse" data-target="#faq-1">Join Us</h4>
                            <!-- // FAQ Header -->

                            <!-- FAQ Content -->
                            <div id="faq-1" class="collapse show" data-parent="#accordion">
                                <div class="faq-body">
                                    Our commitment to deliver a candidate experience which exceeds expectation, every time.	
                                    At Safe Work Solutions, our priority is to place you not just in a job but to help guide and manage your career. <br>
                                    <br>

We work towards productive partnerships with Candidates and Employers alike, and we understand how important it is for a Candidate to work for a company in which they are happy. As a Candidate you can be sure that the companies, we recruit for have been checked to match your needs.
                                </div>
                            </div>
                            <!-- FAQ Content -->
                        </div>
                        <!-- // Single FAQ -->

                        <!-- Single FAQ -->
                        <div class="single-faq">

                            <!-- FAQ Header -->
                            <h4 class="collapsed" data-toggle="collapse" data-target="#faq-2">Why Us?</h4>
                            <!-- // FAQ Header -->

                            <!-- FAQ Content -->
                            <div id="faq-2" class="collapse" data-parent="#accordion">
                                <div class="faq-body">
                                    From registration through to working on the job, our focus is to provide you with a rewarding work experience.<br>
                                    <br>

We take the time to understand your work experience with the aim of placing you in a permanent role.
                                </div>
                            </div>
                            <!-- FAQ Content -->
                        </div>
                        <!-- // Single FAQ -->
                        
                        <!-- Single FAQ -->
                        <div class="single-faq">

                            <!-- FAQ Header -->
                            <h4 class="collapsed" data-toggle="collapse" data-target="#faq-3">Apply</h4>
                            <!-- // FAQ Header -->

                            <!-- FAQ Content -->
                            <div id="faq-3" class="collapse" data-parent="#accordion">
                                <div class="faq-body">
                                    Ready to get started?!
                                    <br>
                                    <br>
                                    Check out our job <a href="displayJobs.php">offers</a>!
                                </div>
                            </div>
                            <!-- FAQ Content -->
                        </div>
                        <!-- // Single FAQ -->

                    </div>
                    <!-- FAQ Content -->
                </div>
            
    </section>
    <!-- ====== // Frequently asked questions ====== -->
    
    
    <!-- ====== Call to Action Area ====== -->
    <section class="section-padding call-to-action-aria bg-secondary">
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <h2></h2>
                    <p></p>
                </div>
                <div class="col-lg-3">
                    <div class="cta-button">
                        <div class="d-table">
                            <div class="d-table-cell">
                                <a style = "position:relative; left:-500px; top:2px; " href="contact.php" class="button">Contact Us</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ====== // Call to Action Area ====== -->
    
    
    
    <!-- ====== // Page Content ====== -->
    
    

 <?php include('./phpfunctions/footer.php') ?>