<?php include('./phpfunctions/header.php') ?> 
    

    <!-- ====== Service Section ====== -->
    <section id="service" class="section-padding pb-70 service-area bg-secondary">
        <div class="container">
            <!-- Section Title -->
            <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="section-title text-center">
                        <h2>CORPORATE FORKLIFT
TRAINING PROGRAMS</h2>
                        <p>Make the right choice for your company. Safe Work Solutions Inc. delivers high-quality, industry recognized forklift training certification.

Delivered by experienced and fully-accredited instructors, we make it simple for people of every experience level to get the skills and qualifications they need. Acquiring forklift certification for your staffs has never been simpler than when you choose to work with our team.</p>
                    </div>
                </div>
            </div>
            <!-- //Section Title -->

            <div class="row">
                <!-- Single Service -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-service">
                        
                        <h2><a href="#" style='color:black' onmouseover="this.style.color='#FFFFFF'"  onmouseout="this.style.color='#000'" >New Operator</a></h2>
                        <p>New Operator / Beginner
Forklift Training Programs are
designed for individuals who
have minimal to no experience
operating a lift truck or
looking to learn a new class

of lift equipment.</p>
                    </div>
                </div>
                <!-- //Single Service -->
                <!-- Single Service -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-service">
                        
                        <h2><a href="#" style='color:black' onmouseover="this.style.color='#FFFFFF'"  onmouseout="this.style.color='#000'" >Intermediate</a></h2>
                        <p>Intermediate Forklift Training
Programs are for individuals
with minimal operating
experience who require
practice, those who have not
been trained professionally.<br><br></p>
                    </div>
                </div>
                <!-- //Single Service -->
                <!-- Single Service -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-service">
                        
                        <h2><a href="#" style='color:black' onmouseover="this.style.color='#FFFFFF'"  onmouseout="this.style.color='#000'" >Advanced</a></h2>
                        <p>Advanced or Renewal Forklift
Training Programs are
designed for experienced
individuals and / or have
been previously certified with
an expired certificate.<br><br></p>
                    </div>
                </div>
                
                
                <!-- //Single Service -->
                
            </div>
        </div>
    </section>
    <!-- ====== //Service Section ====== -->
	




    <!-- corporate forklift training -->
	  <div class="space-top"></div>
    <h3>FORKLIFT TRAINING CERTIFICATION</h3>
	  <div class="space-m"></div>

    <div class="row">
      <div class="col-lg-4 mb-4">
        <div class="card h-100 text-center imagecenter">
         <div class="card-body">
			  <img class="card-img-top" src="assets/images/forklifttraining/training.png" style="height: 200px; width: 200px;" alt="Training">
			  <div class="space-m"></div>
            <h4 class="card-title">Training</h4>
          <p class="card-text text-left">In Quebec, to operate a lift truck which ever category it may be, training is mandatory. This training will allow your employees to acquire or better their knowledge/skills of operating a lift truck. Also it will allow them to get the necessary accreditation/certifiation to operate a lift truck.<br>
</p>           
		  The training time is adjusted according to the candidate's experience. <p></p>
          </div>
          
        </div>
      </div>
      
		<div class="col-lg-4 mb-4">
        <div class="card h-100 text-center imagecenter">
          <div class="card-body">
            <img class="card-img-top " src="assets/images/forklifttraining/time.png" style="height: 200px; width: 200px;" alt="">
			  <div class="space-m"></div>
            <h4 class="card-title ">Duration</h4>
            <p class="card-text text-left">Between 5 to 10 hours per group (depending on experience and type of equipment)</p>
				<ul class="text-left">	
			  		<li>Theory (4Hrs)</li>
					<li>Theory Exam (30Mins)</li>
					<li>Practical Training (30 - 60Mins) Per Lift Truck</li>
					<li>Practical Evaluation (15 - 25mins) Per Lift Truck</li>
				</ul>
          </div>
       </div>
      </div>
      
		<div class="col-lg-4 mb-4">
        <div class="card h-100 text-center imagecenter">
          <div class="card-body">
            <img class="card-img-top " src="assets/images/forklifttraining/location.png" style="height: 200px; width: 200px;" alt="">
			  <div class="space-m"></div>
            <h4 class="card-title ">Location</h4>
            <p class="card-text text-left">The training can be done directly at your facility.</p>
				
          </div>
       </div>
      </div>
    </div>
    <!-- /.row -->
	  
	   <div class="row">
      <div class="col-lg-4 mb-4">
        <div class="card h-100 text-center imagecenter">
          <div class="card-body">
            <img class="card-img-top " src="assets/images/forklifttraining/target.png" style="height: 200px; width: 200px;" alt="">
			  <div class="space-m"></div>
            <h4 class="card-title ">Course Objective</h4>
            <p class="card-text text-left">Our training will guide you through all aspects of Lift Truck Safety, from Pre-Operation Inspection to Stability. <br>Theory: </p>
				<ul class="text-left">	
			  		<li>Type Of Lift Trucks</li>
					<li>Intro &amp; Law</li>
					<li>Basic Safe Operating </li>
					<li>Stability</li>
					<li>Propane</li>
					<li>Battery</li>
					<li>Parking</li>
				</ul>
			  <p class="card-text text-left"><br>Practical:  </p>
			  	<ul class="text-left">
					<li>Pre-Operation Inspection</li>
					<li>Safe Maneuvering Techniques</li>
					<li>Stacking &amp; Uninstalling </li>
					<li>Load Handling</li>
					<li>Propane Exchange / Battery Charging &amp; Maintenance</li>
					<li>Parking </li>
				</ul>
          </div>
       </div>
      </div>
		   
      <div class="col-lg-4 mb-4">
        <div class="card h-100 text-center imagecenter">
          <div class="card-body">
            <img class="card-img-top " src="assets/images/forklifttraining/cost2.png" style="height: 200px; width: 200px;" alt="">
			  <div class="space-m"></div>
            <h4 class="card-title ">Cost Of Training</h4>
            <p class="card-text text-left">We offer quality training at a very competitive price! <br>
			Contact our customer service! <br><br>
			<strong>Note:</strong> For your convenience we accept checks and all major credit cards.)</p>
				
          </div>
       </div>
      </div>
		   
     <div class="col-lg-4 mb-4">
        <div class="card h-100 text-center imagecenter">
          <div class="card-body">
            <img class="card-img-top " src="assets/images/forklifttraining/Certificate.png" style="height: 200px; width: 200px;" alt="">
			  <div class="space-m"></div>
            <h4 class="card-title ">Documents We Provide</h4>
            <p class="card-text text-left">We provide the following documents during and after training. </p>
				<ul class="text-left">	
			  		<li>Training Manuel </li>
					<li>Theory &amp; Practical Tests</li>
					<li>Paper Certificate </li>
					<li>PDF Certificate (Emailed)</li>
				</ul>
          </div>
       </div>
      </div>
    </div>
    <!-- /.row -->
	  
	  
 

    <!-- //Page Content -->


    
<?php include('./phpfunctions/footer.php') ?> 