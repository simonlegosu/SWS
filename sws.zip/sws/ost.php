<?php include('./phpfunctions/header.php') ?> 
      
    
<!-- ====== Blog Section ====== -->
    <section class="section-padding pb-70 blog-section bg-light">
        <div class="container">
            <!-- Section Title -->
            <div class="row justify-content-center">
                <div class="col-lg-6 "><br><br>
                    <div class="section-title text-center">
                        <h2>Online Safety Training</h2>
                        <p>All our online safety trainings.</p>
                    </div>
                </div>
            </div>
            <!-- //Section Title -->
            <div class="row">
                <!-- Single Blog -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-blog">
                        <a href="WHMIS.php"><div class="blog-thumb" style="background-image: url(assets/images/blog/img-1.png)"></div></a>
                    </div>
                </div>
                <!-- Single Blog -->
                <!-- Single Blog -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-blog">
                        <a href="TDG.php"><div class="blog-thumb" style="background-image: url(assets/images/blog/img-2.png)"></div></a>
                    </div>
                </div>
                <!-- Single Blog -->
                <!-- Single Blog -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-blog">
                        <a href="fall-protection.php"><div class="blog-thumb" style="background-image: url(assets/images/blog/img-3.png)"></div></a>
                        
                    </div>
                </div>
                <!-- Single Blog -->
                <!-- Single Blog -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-blog">
                        <a href="fireextinguisher.php"><div class="blog-thumb" style="background-image: url(assets/images/blog/img-4.png)"></div></a>
                    </div>
                </div>
                <!-- Single Blog -->
                <!-- Single Blog -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-blog">
                        <a href="aeriallifts.php"><div class="blog-thumb" style="background-image: url(assets/images/blog/img-5.png)"></div></a>
                    </div>
                </div>
                <!-- Single Blog -->
                <!-- Single Blog -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-blog">
                        <a href="lockouttagout.php"><div class="blog-thumb" style="background-image: url(assets/images/blog/img-6.png)"></div></a>
                    </div>
                </div>
                <!-- Single Blog -->
                <!-- Single Blog -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-blog">
                        <a href="confinedspace.php"><div class="blog-thumb" style="background-image: url(assets/images/blog/img-7.png)"></div></a>
                    </div>
                </div>
                <!-- Single Blog -->
                <!-- Single Blog -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-blog">
                        <a href="ppe.php"><div class="blog-thumb" style="background-image: url(assets/images/blog/img-8.png)"></div></a>
                    </div>
                </div>
                <!-- Single Blog -->
                <!-- Single Blog -->
                <div class="col-lg-4 col-md-6">
                    <div class="single-blog">
                        <a href="cranesafety.php"><div class="blog-thumb" style="background-image: url(assets/images/blog/img-9.png)"></div></a>
                    </div>
                </div>
                <!-- Single Blog -->
            </div>
        </div>
    </section>
    <!-- ====== // Blog Section ====== --> 
    

    
<?php include('./phpfunctions/footer.php') ?> 