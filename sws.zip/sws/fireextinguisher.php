<?php include('./phpfunctions/header.php') ?> 
    <!-- ====== Page Content ====== -->
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    
<div class="container">
 <div class="space-top"></div>
	  <div class="space-m"></div>
    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3"></h1>
    

  
    <div class="row">

      <!-- Blog Entries Column -->
      <div class="col-md-8">

        <!-- Blog Post -->
        <div class="card-noborder mb-4">
          <img class="card-img-top imgborder" src="assets/images/fireextinguisher/fireextinguisherpage.png" alt="looking for staff">
          <div class="card-body">
            
            <p class="card-text">
			<strong>Safe Work Practice For Fire Extinguisher</strong><br>
			This Online Fire Extinguishers Course will guide you through all aspects of Fire Extinguishers, from the types of fires, to the classes of Fire Extinguishers. Our comprehensive course will explain in detail what you need to know, emphasize key points and test your knowledge retention after each module. The course has been designed to teach you what you need to know to safely operate a fire extinguisher and understand what types of extinguishers can be used on what types of fires, as well as maintenance and fire safety, so by completing this course you can become a better educated worker and improve your knowledge of an important part in workplace safety.
			</p>
			  
			  <div class="row">
				   <div class="col-md-6">
						<ul class="fa-ul bigli">
                                                    <br>
						  <li><i class="fa-li fa far fa-clock fa-2x text-icon"></i>Average Duration: 2 Hours</li>
                                                  <br>
						  <li><i class="fa-li fa fa-print fa-2x text-icon"></i>Printable Certificate Upon Completion</li>
                                                  <br>
						  <li><i class="fa-li fa fas fa-graduation-cap fa-2x text-icon"></i>Unlimited Exam Attempts</li>
                                                  <br>
						  <li><i class="fa-li fas fa-university fa-2x text-icon"></i>Standards Compliant </li>
                                                  <br>
						 </ul>
				   </div>
				   <div class="col-md-6">
						<ul class="fa-ul bigli">
                                                    <br>
						  <li><em class="fa-li fas fa-calendar-alt fa-2x text-icon"></em>Self-Paced. Available 24/7</li>
                                                  <br>
						  <li><i class="fa-li fas fa-users fa-2x text-icon"></i>User Management Tools Available</li>
                                                  <br>
						  <li><i class="fa-li 	far fa-file-alt fa-2x text-icon"></i>Permanent Record Of Training</li>
                                                  <br>
						  <li><i class="fa-li 	fas fa-comment-alt fa-2x text-icon"></i>Live Student Support</li>
                                                  <br>
						</ul>
					</div>
            </div>
         
        </div>
      </div>

      </div>

      <!-- Sidebar Widgets Column -->
      <div class="col-md-4">

        <!-- Search Widget -->
        <div class="card mb-4">
          <h5 class="card-header">Course Outline</h5>
          <div class="card-body">
			
			 <ul>  
				    <li>What is the ‘Fire Triangle”?</li>
					<li>What are the different classes of fires?</li>
					<li>How to use and maintain the different types of fire extinguishers</li>
					<li>How to prevent fires from starting and spreading</li>
				 					 
				</ul>
			 <div class="text-center">
			  	<a style="border-color: black;color: black; background-color: #ffc900" class="btn btn-primary btn-larg" href="contact.html">GET INFORMATION
          		<span class="glyphicon glyphicon-chevron-right"></span></a> 
			  </div>
			  
          </div>
        </div>


       
      </div>

    </div>
    <!-- /.row -->

  </div>
    
    <!-- ====== // Page Content ====== -->
    
 <?php include('./phpfunctions/footer.php') ?> 