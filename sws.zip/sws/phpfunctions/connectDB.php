<?php

    $user = 'simonlegosu';
	$pass = 'simonlegosu';
	$host = 'localhost';
	$db = 'jobsdb';  
        $conn = new mysqli($host, $user, $pass, $db);
	if ($conn->connect_error) 
        {
            die($conn->connect_error);
        }
        