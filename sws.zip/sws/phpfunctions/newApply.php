<?php
include('phpfunctions\connectDB.php');
if (isset($_POST['prenom']) AND isset($_POST['nom']) AND isset($_POST['no_tel']) AND isset($_POST['email']) AND isset($_POST['scolarite']) AND isset($_POST['experience']))    
{  


$targetDir = "C:/xampp/htdocs/chowd/CV";
$target_file = $targetDir . basename($_FILES["CVtoUpload"]["name"]);

if(is_array($_FILES))
{
    if(is_uploaded_file($_FILES['CVtoUpload']['tmp_name'])) 
    {
        if(move_uploaded_file($_FILES['CVtoUpload']['tmp_name'],"$targetDir/".$_FILES['CVtoUpload']['name'])) 
        {
            echo "File uploaded successfully";
        }
    }
    $CVname = $_FILES['CVtoUpload']['name'];
    $CVType = $_FILES['CVtoUpload']['type'];
    $CVSize = ($_FILES['CVtoUpload']['size'] /1024 ); 
    
}
    $ID_job = $_POST['ID_job'];
    $prenom = $_POST['prenom'];
    $nom = $_POST['nom'];    
    $notel = $_POST['no_tel'];
    $email = $_POST['email'];
    $scolarite = $_POST['scolarite'];
    $experience = $_POST['experience'];
    $coverletter = $_POST['coverletter'];
    
    
    $sql1 = "CALL addCV('$CVname', '$CVType', '$CVSize', '$target_file', @out_ID_cv)";  
    
    if (!($stmt = $conn->prepare($sql1))) {
        echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
    }

    if (!$stmt->execute()) {
        echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
    }

    do {

        $ID_cv = NULL;
        if (!$stmt->bind_result($ID_cv)) {
            echo "Bind failed: (" . $stmt->errno . ") " . $stmt->error;
        }

        while ($stmt->fetch()) {
            //echo "id = $id_out\n";
        }
    } while ($stmt->more_results() && $stmt->next_result());
      
    
    
    
    
    
    $sql2  = "CALL addApplication('$prenom', '$nom', '$email', '$notel', '$scolarite', '$experience', '$ID_job', '$ID_cv', '$coverletter')";

    if (!($stmt2 = $conn->prepare($sql2))) {
        echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
    }
    
    
    if (!$stmt2->execute()) {
        echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;      

        
    }
    
     
}

$query  = "SELECT Titre FROM showJobs WHERE ID_job = $ID_job";

    	$result = $conn->query($query);
	if (!$result) 
        {
            die ("Échec d'accès à la base de données : " . $conn->error);
        }
        
	$rows = $result->num_rows;
	for ($j = 0 ; $j < $rows ; ++$j)
	{
            $result->data_seek($j);
            $row = $result->fetch_array(MYSQLI_NUM);
            
        }

$resultat = <<<_END
<section class="section-padding faq-area bg-secondary center">
        <div class="container">
            <!-- Section Title -->
            <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="section-title text-center faq-title">
                        <h2>Application Succesful!</h2><br>
                            <p>You have successfully registered your application for $ID_job - $row[0].</p>
                            <p></p><br>
                            <img src="assets/images/logo.png">
        
                    </div>
                </div>
            </div>

        <div class="container">
            <div class="row justify-content-center">
                
                    <div class="cta-button">
                    <a style = "top:2px;" href="contact.php" class="button">Contact Us</a>

                    </div>
                
            </div>
        </div>
    </section>
_END;
        
$conn -> close();

echo $resultat;

?>

