<?php
$header = <<<_END
<!DOCTYPE html>
<html lang="en">
    
    

<head>
    
    <link rel="shortcut icon" href="assets/images/logo.png" />
    <link rel="apple-touch-icon" href="assets/images/logo.png" />
    
    <meta content='width=device-width, initial-scale=1' name='viewport'/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta charset="UTF-8">
    
    <title>Safe Work Solutions</title>

    <!-- ====== Google Fonts ====== -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600" rel="stylesheet">

    <!-- ====== ALL CSS ====== -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/lightbox.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    
    

</head>

<body data-spy="scroll" data-target=".navbar-nav">
    
     <!-- Preloader -->
    <div class="preloader">
        <div class="spinner">
            <div class="cube1"></div>
            <div class="cube2"></div>
        </div>
    </div>
    <!-- // Preloader -->
    
    <!-- ====== Header ====== -->
    <header id="header" class="header">
        <!-- ====== Navbar ====== -->
        <nav class="navbar navbar-expand-lg fixed-top">
            <div class="container">
                
                <!-- Logo -->
                    <a class="navbar-brand logo" href="index.php">
                    <img src="assets/images/logo.png" alt="logo">
                </a>

                <!-- // Logo -->
                <div class='socialnavbar'>
                <ul style='position: relative; left: -250px; bottom: -5px' class="list-inline social-buttons">
            <li class="list-inline-item">
              <a style='color: black;' href="https://twitter.com/sws_canada">
                <i class="fab fa-twitter"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a style='color: black;' href="https://www.facebook.com/swscanada/">
				 <i class="fab fa-facebook-f"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a style='color: black;' href="https://www.linkedin.com/company/safeworksolutions">
                <i class="fab fa-linkedin-in"></i>
              </a>
            </li>
			  <li class="list-inline-item">
              <a style='color: black;' href="https://www.instagram.com/swscanada/">
                <i class="fab fa-instagram"></i>
              </a>
            </li>
          </ul>
</div>
                <!-- Mobile Menu -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-expanded="false"><span><i class="fa fa-bars"></i></span></button>
                <!-- Mobile Menu -->

                <div class="collapse navbar-collapse main-menu" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active"><a class="nav-link" href="index.php">HOME</a></li>
                        <li class="nav-item"><a class="nav-link" href="forklifttraining.php">FORKLIFT TRAINING</a></li>
                        <li class="nav-item"><a class="nav-link" href="ost.php">ONLINE SAFETY TRAINING</a></li>
                        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             STAFFING
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
              <a class="dropdown-item" href="looking.php">Looking For Staff</a>
              <a class="dropdown-item" href="job-seekers.php">Job Seekers</a>
             
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             EQUIPMENT
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
                <a class="dropdown-item" href="abouter.php">About</a>
              <a class="dropdown-item" href="service.php">Service</a>
              <a class="dropdown-item" href="sales.php">Sales</a>
              <a class="dropdown-item" href="rentals.php">Rentals</a>
              
             
            </div>
          </li>
                                  
                                                          
                        <li class="nav-item"><a class="nav-link pr0" href="contact.php">CONTACT</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- ====== // Navbar ====== -->
    </header>
<!-- ====== // Header ====== -->
_END;
echo $header;
?>
        

