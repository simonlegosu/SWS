<?php
$footer = <<<_END
<footer class="footer-area">
        <div class="container">
            <div class="row">
                <div style='text-align: left; max-width: 100%'>
                <h6 style='color: white; ' class="CPMT">ACCREDITED BY: &nbsp; &nbsp; &nbsp;</h6><br>
                <img style='' alt="CPMT" src="assets/images/marche.gif"></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;



                
                <center><div class="copyright-text">
                        
          <ul class="list-inline social-buttons">
            <li class="list-inline-item">
              <a href="https://twitter.com/sws_canada">
                <i class="fab fa-twitter"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="https://www.facebook.com/swscanada/">
				 <i class="fab fa-facebook-f"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="https://www.linkedin.com/company/safeworksolutions">
                <i class="fab fa-linkedin-in"></i>
              </a>
            </li>
			  <li class="list-inline-item">
              <a href="https://www.instagram.com/swscanada/">
                <i class="fab fa-instagram"></i>
              </a>
            </li>
          </ul>
        
                        <p class="text-white">&copy; Copyright 2019. All Rights Reserved. Design: <a href="https://etwebdesign.ca/">E.T. Web Design</a></p>
                        <br>
                        <p style= '' id="p-simple"><a class="portfolio-link" data-toggle="modal" href="#portfolioModal0">Privacy Policy</a></p>
                    </div></center>
                </div>
            </div>
        
        
    </footer>
    <!-- ====== // Footer Area ====== -->



    
    <!-- ====== Portofolio Area ====== -->
    
    
    
    <div class="portfolio-modal modal fade" id="portfolioModal0" role="dialog" tabindex="-1" style="display: none;" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="close-modal" data-dismiss="modal">
<div class="lr">
<div class="rl"></div>
</div>
</div>

<div class="container">
<div class="row">
<div class="col-lg-8 mx-auto">
<div class="modal-body"><!-- Project Details Go Here -->
<h6 class="text-uppercase textleft">What information do we collect?</h6>

<p class="item-intro text-muted textleft">We collect information from you when you register on our site or fill out a form.</p><br>

<h6 class="text-uppercase textleft">What do we use your information for?</h6>

<p class="item-intro text-muted textleft">Any of the information we collect from you may be used in any of the following ways:</p>

<ul>
	<li>To personalize your experience and to better respond to your individual needs.</li>
	<li>To improve our website based on the information and feedback we receive from you.</li>
	<li>To improve customer service by responding more effectively to your requests and support needs.</li>
	<li>To process job applications Your public and private information will not be sold, exchanged, transferred, or given to any other company for any reason, other than for the express purpose of processing your job application.</li>
        <li>To send periodic emails The email address you provide may be used to send you information and updates pertaining to your application or inquiry. In addition, you may receive occasional updates on company news or related service information.<br></li>
</ul>

<h6 class="text-uppercase textleft">How do we protect your information?</h6>

<p class="item-intro text-muted textleft">We employ a variety of security measures to protect the safety of your personal information.</p><br>

<h6 class="text-uppercase textleft">Do we use cookies?</h6>

<p class="item-intro text-muted textleft">Yes, we use cookies to track web visits. This helps us to better understand how visitors use our site and helps us improve our online marketing communications.</p><br>

<h6 class="text-uppercase textleft">Do we disclose any information to outside parties?</h6>

<p class="item-intro text-muted textleft">We do not sell, trade, or otherwise transfer your personally identifiable information to outside parties. This does not include trusted third parties who assist us in operating our website, conducting our business, or servicing you – so long as those parties agree to keep this information confidential. We may release your information when we believe it is appropriate to comply with the law, enforce our site policies, or protect ours or others' rights, property or safety. However, non-personally identifiable visitor information may be provided to other parties for marketing, advertising or other uses.</p><br>

<h6 class="text-uppercase textleft">Third Party Links</h6>

<p class="item-intro text-muted textleft">Occasionally, at our discretion, we may include links to third party information, services, or products on our website. These third party sites have separate and independent privacy policies. We therefore have no responsibility or liability for the content and activities of these linked sites. Nonetheless, we seek to protect the integrity of our site and welcome any feedback about these sites.</p><br>

<h6 class="text-uppercase textleft">Online Privacy Policy Only</h6>

<p class="item-intro text-muted textleft">This online privacy policy applies only to information collected through our website and not to information collected offline.</p><br>

<h6 class="text-uppercase textleft">Your Consent</h6>

<p class="item-intro text-muted textleft">By using our site, you consent to this privacy policy.</p><br>

<h6 class="text-uppercase textleft">Changes to our Privacy Policy</h6>

<p class="item-intro text-muted textleft">If we decide to amend our privacy policy, we will post those changes on this page. This policy was last modified on August 23, 2019.</p><br>

<h6 class="text-uppercase textleft">Contacting Us</h6>

<p class="item-intro text-muted textleft">If you have any questions or concerns regarding this privacy policy, please contact us at:<br>
Safe Work Solutions Inc.<br>
3700 Rue Griffith<br>
Saint-Laurent, (Quebec) H4T 2B3<br>
514-227-3470</p><br>
<button style='color: black; background-color: #ffc900; border-color: black;' class="btn btn-primary" data-dismiss="modal" type="button">Close</button></div>
</div>
</div>
</div>
</div>
</div>
</div>
    
    
    
    
    
    <!-- ====== // Portofolio Area ====== -->
    
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5c9aa7c21de11b6e3b05586a/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->


     <!-- ====== ALL JS ====== -->
   <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/lightbox.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/jquery.mixitup.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/typed.js"></script>
    <script src="assets/js/skill.bar.js"></script>
    <script src="assets/js/fact.counter.js"></script>
    <script src="assets/js/main.js"></script>
    <script>
  particlesJS.load('particles-js', 'particles.json', function(){
    console.log('particles.json loaded...do your thing!');
  });
</script>
    <script type ='text/javascript' src="particles.js"></script>
    <script type ='text/javascript' src="app.js"></script>

</body>

</html>
_END;
echo $footer;
?>

