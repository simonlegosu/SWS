<?php
include('phpfunctions\connectDB.php');

$ID_job = $_GET['ID_job'];

$query  = "SELECT * FROM detailsjob WHERE ID_job = $ID_job";        
        
	$result = $conn->query($query);
	if (!$result) 
        {
            die ("Échec d'accès à la base deasdasdasd données : " . $ID_job. "  " . $conn->error);
        }
        
	$rows = $result->num_rows;
        for ($j = 0 ; $j < $rows ; ++$j)
	{
            $result->data_seek($j);
            $row = $result->fetch_array(MYSQLI_NUM);
        }
        

        
$jobdetails = <<<_END
<div class="another">
<section class="section-padding">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="section-title2 text-center">
                        <h2>$row[0] -  $row[1]</h2>
                        <p></p>
                    </div>
            </div>

            
            <div class="col-md-12 main-content">
        <div class="text-left">
                        <h2>Job Description</h2>
                        <br>
                    </div>
                            <p>$row[9]</p>
            </div>
        </div>
</div>
<div class="contact-Page">
<br>        
<hr/>
        <br>
        <div class="container">
            
                <div class="section-title2 text-center">
                    <h2>Details</h2>
                </div>         

        
            <div class="row">
                <div class="col-sm-3 part-left">
                    <h6>Degree :  $row[6] </h6>
                </div>
                <div class="col-sm-3 part-left">
                    <h6>Schedule :  $row[8] </h6>
                </div>
                        <div class="col-sm-3 part-right">
                    <h6>Experience : $row[5]</h6>
                </div>
                <div class="col-sm-3 part-right">
                    <h6>Salary : $$row[7]/hour </h6>
                </div>
            </div>
        </div>
        <br>
        <hr/>
        <br>
        <div class="container">
            <div class="section-title2">
                <div class='section-title2 text-center'>
                    <h2>Fill an application</h2>
                </div>
        <p></p>
                <div class='text-center'>
                    <h3><span style='color: #141f2b'>Job posted on : $row[4]</span></h3>
                </div>
            </div>
        </div>
        
     
        
        <div class="container py-5 main">
            <div class="row">
                <div class="col-md-12" data-aos="fade-up" data-aos-duration="500">
                    <form action="application.php" method="POST" enctype="multipart/form-data">
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="prenom" placeholder="First Name*" required>
                            </div>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="nom" placeholder="Last name*" required>
                            </div>

                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="no_tel" placeholder="Phone Number*" required>
                            </div>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="email" placeholder="E-mail*" required>
                            </div>
                        </div> 
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <select class="form-control" name="scolarite" required>
                                <option class="form-control" value="-1"> Degree* </option>
                                <option class="form-control" value="1" >DES </option>
                                <option class="form-control" value="2" > DEP </option>
                                <option class="form-control" value="3" > DEC/AEC </option>
                                <option class="form-control" value="4" > BAC </option>
                                <option class="form-control" value="5" > MAITRISE </option>
                                <option class="form-control" value="6" > PhD </option>
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <select class="form-control" name="experience" required>
                                <option class="form-control" value="-1" > Experience* </option>
                                <option class="form-control" value="1" >0-2 </option>
                                <option class="form-control" value="2" > 3-5 </option>
                                <option class="form-control" value="3" > 6-9 </option>
                                <option class="form-control" value="4" > 10+ </option>
                                </select>
                            </div>
                        </div>
                                                   

                        
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <p><label for="CV">Add your CV*</label><input type="file" name="CVtoUpload" id="CVtoUpload"class="form-control" required/></p>

                            </div>
                        </div>
                        </div>
                </div>
                <div class="clearfix">
                    
                </div>        
                    <input type="hidden" name="ID_job" value="$ID_job" >                                       
                    <div class="clearfix"></div> 
                    
                    <div class="col-md-12">
                        <div class="form-group row">
                            <div class="col-sm-12">
                                <textarea type="text" class="form-control" name="coverletter" placeholder="Message to the employer" rows="8"></textarea>
                            </div>
                        </div>
                        <input class="btn btn-primary px-4" type="submit" value="Apply" name="submit" id="submit"/>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </section>   
<br>
<br>
_END;
echo $jobdetails;
$conn->close();
?>

