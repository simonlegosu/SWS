<?php	
include_once('phpfunctions\connectDB.php');

if (isset($_GET["page"])) 
        { 
        $page  = $_GET["page"];
        if ($page > 1){
        $start_from = (($page-1) * 10);
        }
        else
        {
            
            $page=1;
            $start_from = 0;
        }
    } 
else 
    { 
        
        $page=1; 
        $start_from = 0;
    }    

 
    
    
if (isset($_POST['submitSearch']))
{
    if (isset($_POST['search_keywords']))
    {
        $search = $_POST['search_keywords'];
    } else {$search = "";}
    if (isset($_POST['field']))
    {
        $field = $_POST['field'];
    }

    if (isset($_POST['jobtype']))
    {
        $jobtype = $_POST['jobtype'];
    }

    if (isset($_POST['location']))
    {
        $location = $_POST['location'];
    }
    $results = [];
    $resultsearch = [];    
    
    $queryCRIT = "CALL searchjobCriterias('$search', $field, $jobtype, $location)";
    
    
    $resultCRIT = $conn->query($queryCRIT);
    
    
    
    
    	if (!$resultCRIT) 
        {
            die ("Échec d'accès à la base de données : " . $conn->error);
        }
        $rowsCRIT = $resultCRIT->num_rows;
	for ($j = 0 ; $j < $rowsCRIT ; ++$j)
	{
            $resultCRIT->data_seek($j);
            $rowCRIT = $resultCRIT->fetch_array(MYSQLI_NUM);         
            
            $results[$j] = $rowCRIT;
                 
        }                              
        $conn->next_result();
        $cnt = count($results);
        $queue = $cnt-1;

 
    for ($q = 0; $q < $cnt; ++$q)    {  
        $value = $results[$queue][0];
        
        $query  = "SELECT * FROM showJobs WHERE ID_job = $value ORDER BY ID_job DESC LIMIT $start_from, 10";
        $result = $conn->query($query);
	if (!$result) 
        {
            die ("Échec d'accès à la base de données : " . $conn->error);
        }
        
	$rows = $result->num_rows;
	for ($j = 0 ; $j < $rows ; ++$j)
	{
            
        echo "<div class='row' style='border:1px solid #141f2b; margin-left: 15%; margin-right : 15%;'>";
            $result->data_seek($j);
            $row = $result->fetch_array(MYSQLI_NUM);
            $resultsearch[$j] = $row[0];
                echo "<div class='col-md-5'><div><h4><a href='application.php?ID_job=$row[0]'><i class='fa fa-suitcase' aria-hidden='true'></i><span class='job-title'> #$row[0] - $row[1]</span></a></h4></div></div>";    
               
                for ($k = 2 ; $k < 5 ; ++$k) 
                {                           
                    echo "<div class='col-md-2 col-sm-4 col-xs-12'>
                                <div><i class='fa fa-suitcase' aria-hidden='true'></i> $row[$k]</div>
                            </div>";                    
                } 
        echo "</div><br>";

        }
        $queue =  $queue - 1;
}
    $cnt3 = count($resultsearch);
        if ($cnt3 > 10){
        $total_pages = (intdiv($cnt, 10) + 1); // calculate total pages with results       
        } else
        {
            $total_pages = 1;
        }
        if ($cnt3 > 10)
        {
            
        for ($i=1; $i<=$total_pages; $i++)
        
        {  // print links for all pages
            
            echo "<a class='btn-outline-secondary' href='displayJobs.php?page=$i'>  ". $i ."  </a>";
            
            
        }
        }
        
    $conn -> close();
    
}





else 
{
    $resultat = [];
    
    $query  = "SELECT * FROM showJobs ORDER BY ID_job DESC LIMIT $start_from, 10";
    	$result = $conn->query($query);
	if (!$result) 
        {
            die ("Échec d'accès à la base de données : " . $conn->error);
        }
        
	$rows = $result->num_rows;
        
	for ($j = 0 ; $j < $rows ; ++$j)
	{
        echo "<div class='row bg-white' style='border:1px solid #141f2b'>";
            $result->data_seek($j);
            $row = $result->fetch_array(MYSQLI_NUM);
            $resultat[$j] = $row[0];
            
                echo "<div class='col-md-5'><div><h4><a href='application.php?ID_job=$row[0]'><i class='fa fa-suitcase' aria-hidden='true'></i><span class='job-title'> #$row[0] - $row[1]</span></a></h4></div></div>";    
               
                for ($k = 2 ; $k < 5 ; ++$k) 
                {                           
                    echo "<div class='col-md-2 col-sm-4 col-xs-12'>
                                <div><i class='fa fa-suitcase' aria-hidden='true'></i> $row[$k]</div>
                            </div>";                    
                } 
        echo "</div><br>";
        }
        
        $cnt2 = count($resultat);
        if ($cnt2 = 10){
        $total_pages = (intdiv($cnt2, 10) + 1); // calculate total pages with results
        
        for ($i=1; $i<=$total_pages; $i++)
        
        {  // print links for all pages
            
            echo "<a class='button' href='displayJobs.php?page=$i'>  ". $i ."  </a>";
            
            
        }

        }

        $conn -> close();

}

?>
                            
                
                            
                            
                
