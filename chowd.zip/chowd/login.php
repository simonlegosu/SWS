<!doctype html>

<?php include('./phpfunctions/header.php') ?> 
<br>
<br>
<br>
<br>
<br>
<?php

if (isset($_GET['submit']))
{
    $username = $_GET['Username'];
    $password = $_GET['Password'];
    
    if ($username === "Mehran2020" && $password === "6891337")
    {
       include('./phpfunctions/admin.php');
    }
}
else
{
$login = <<<_END
<div class="container">   
    <div class="row box-1" data-aos="fade-up" data-aos-duration="500">
            <fieldset>
                <legend>Login</legend>

                <form method="GET" action="login.php">
                    <p><label for="Username">Username : </label>
                    <input type="text" name="Username" id="Username" autofocus="true" required /></p>
                    <p><label for="Password">Password : </label>
                    <input type="password" name="Password" id="Password" required/></p>
                    <input type="submit" value="Valider" name="submit" id="submit"/>
                </form>           
            </fieldset> 
    </div>
</div>          
_END;

echo $login;
}
?>

<br>
<br>
<br>
<br>
<br>


<?php include("phpfunctions\basdepage.php") ?>



