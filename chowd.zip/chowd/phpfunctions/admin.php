<!doctype html>
<!--inclure lien dans le footer du site-->
<?php
include('connectDB.php');
if (isset($_GET['ID_jobDel']))
{
    $id_jobdel = $_GET['ID_jobDel'];
    
    $sql2 = "DELETE FROM jobs WHERE ID_job = $id_jobdel";
    $result = $conn->query($sql2);
	if (!$result) 
        {
            die ("Échec d'accès à la base de données : " . $conn->error);
        }
        else
        {
            echo "Job deleted<br>";
        }
}
if (isset($_GET['submitjob']))
{
    $titre = $_GET['Title'];
    $salaire = $_GET['Salary'];
    $field = $_GET['field'];
    $typeEmp = $_GET['jobtype'];
    $lieux = $_GET['location'];
    $schedule = $_GET['Schedule'];
    $jobdesc = $_GET['jobdesc'];
    $scolarite = $_GET['scolarite'];
    $experience = $_GET['experience'];
    
    $sql1 = "CALL newJob('$titre', '$typeEmp', '$lieux', '$jobdesc', '$schedule', '$salaire', '$scolarite',  '$experience', '$field', @out_ID_job)";
    if (!($stmt = $conn->prepare($sql1))) {
        echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
    }

    if (!$stmt->execute()) {
        echo "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
    }

    do {

        $ID_cv = NULL;
        if (!$stmt->bind_result($ID_newJob)) {
            echo "Bind failed: (" . $stmt->errno . ") " . $stmt->error;
        }

        while ($stmt->fetch()) {
            //echo "id = $id_out\n";
        }
    } while ($stmt->more_results() && $stmt->next_result());
    echo "New job added! ID job = $ID_newJob <br>";
    echo "You can add more jobs or return to the main page<br>";
}
?>
<br>
<br>
<br>
<br>
<br>

<div class="container">
<a href='/chowd/index.php'>Main Page</a>   
<h1>Admin</h1>        
            <fieldset>
                
                <legend>Add job</legend>
                <form action='phpfunctions/admin.php'>
                    <div class="col-sm-3">
                    <select  name='field' id='category' class='form-control' data-aos="fade-right" data-aos-duration="500">
                    <option value='999'>Field</option>
                    <?php
                include ("phpfunctions\connectDB.php");
                $query3 = "SELECT * FROM domain_ref";
                $result3 = $conn->query($query3);
                if (!$result3) 
                {
                    die ("Échec d'accès à la base deasdasdasd données : " . $conn->error);
                }

                $row3s = $result3->num_rows;
                for ($j = 0 ; $j < $row3s ; ++$j)
                {
                    $result3->data_seek($j);
                    $row3 = $result3->fetch_array(MYSQLI_NUM);
                    echo "<option class='control' value='$row3[0]'>$row3[1]</option>";
                }
               
                ?> 
        </select>
                        </div>
        
<div class="col-sm-3">
            <select  name='jobtype' id='jobtype' class='form-control' data-aos="fade-right" data-aos-duration="500">
                <option value='999'>Job Type</option>                
                    
                <?php
                
                $query2 = "SELECT * FROM typeemploi_ref";
                $result2 = $conn->query($query2);
                if (!$result2) 
                {
                    die ("Échec d'accès à la base deasdasdasd données : " . $conn->error);
                }

                $row2s = $result2->num_rows;
                for ($j = 0 ; $j < $row2s ; ++$j)
                {
                    $result2->data_seek($j);
                    $row2 = $result2->fetch_array(MYSQLI_NUM);
                    echo "<option class='control' value='$row2[0]'>$row2[1]</option>";
                }
                
                ?>                
                    </select>
                </div>
        
                <div class="col-sm-3">
            <select  name='location' id='location' class='form-control' data-aos="fade-left" data-aos-duration="500">
	<option value='999'>Location</option>
        <?php
        
        $query = "SELECT * FROM lieux_ref";
        $result = $conn->query($query);
	if (!$result) 
        {
            die ("Échec d'accès à la base lieux données : " . $conn->error);
        }
        
	$rows = $result->num_rows;
        for ($j = 0 ; $j < $rows ; ++$j)
	{
            $result->data_seek($j);
            $row = $result->fetch_array(MYSQLI_NUM);
            echo "<option class='level-0' value='$row[0]'>$row[1]</option>";
        }
        
        ?>

            </select>
        </div> 
        
                     <div class="col-sm-3">
                                <select class="form-control" name="scolarite" required>
                                <option class="form-control" value="-1"> Degree* </option>
                                <option class="form-control" value="1" >DES </option>
                                <option class="form-control" value="2" > DEP </option>
                                <option class="form-control" value="3" > DEC/AEC </option>
                                <option class="form-control" value="4" > BAC </option>
                                <option class="form-control" value="5" > MAITRISE </option>
                                <option class="form-control" value="6" > PhD </option>
                                </select>
                            </div>
                            <div class="col-sm-3">
                                <select class="form-control" name="experience" required>
                                <option class="form-control" value="-1" > Experience* </option>
                                <option class="form-control" value="1" >0-2 </option>
                                <option class="form-control" value="2" > 3-5 </option>
                                <option class="form-control" value="3" > 6-9 </option>
                                <option class="form-control" value="4" > 10+ </option>
                                </select>
                            </div>
                        
                    <div class="col-sm-3">                        
                        <input type="text" class="form-control" placeholder="Title" id="keywords" name="Title">
                    </div>
                    
                    <div class="col-sm-3">                        
                        <input type="text" class="form-control" placeholder="Schedule" id="keywords" name="Schedule">
                    </div>
                    
                    <div class="col-sm-3">                        
                    <input type="text" class="form-control" placeholder="Salary" id="keywords" name="Salary">
                    </div>
                    
        
                    <div class="col-sm-12">
                                <textarea type="text" class="form-control" name="jobdesc" placeholder="Job Description" rows="8"></textarea>
                    </div>
                    
                    <input type="submit" name="submitjob" id="submitjob" value="Submit" />                   
                </form>
                
          
            </fieldset>
</div>
<br>
<hr>
<br>
<?php
$query  = "SELECT * FROM showJobs ORDER BY ID_job DESC";
    	$result = $conn->query($query);
	if (!$result) 
        {
            die ("Échec d'accès à la base de données : " . $conn->error);
        }
        
	$rows = $result->num_rows;
        
	for ($j = 0 ; $j < $rows ; ++$j)
	{
        echo "<div class='row' style='border:1px solid #141f2b; margin-left: 15%; margin-right : 15%;'>";
            $result->data_seek($j);
            $row = $result->fetch_array(MYSQLI_NUM);
            $resultat[$j] = $row[0];
            
                echo "<div class='col-md-5'><div><h4><span class='job-title'> #$row[0] - $row[1]</span></h4><a href='phpfunctions/admin.php?ID_jobDel=$row[0]'>Delete</a></div></div>";    
               
 
        echo "</div><br>";
        }
        ?>
        <br>
          
          

<br>
<br>
<br>
<br>
<br>

